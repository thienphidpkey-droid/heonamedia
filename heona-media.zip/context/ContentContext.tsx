
import React, { createContext, useContext, useState, useEffect } from 'react';
import { ContentState, Project, Service, ContactInfo } from '../types';

// 🔧 Hàm chuẩn hóa link Google Drive thành direct link dùng cho <img>
const normalizeDriveUrl = (url: string): string => {
  if (!url) return url;

  // Đã là /h6.jpg, /h7.jpg hoặc domain khác => giữ nguyên
  if (url.startsWith('/')) return url;
  if (!url.includes('drive.google.com') && !url.includes('drive.usercontent.google.com')) {
    return url;
  }

  // Nếu đã ở dạng uc?export=view thì giữ nguyên
  if (url.includes('uc?export=view')) return url;

  // Lấy id=... từ query (dùng cho drive.usercontent.google.com hoặc link convert)
  const idMatch = url.match(/[?&]id=([^&]+)/);
  if (idMatch && idMatch[1]) {
    const id = idMatch[1];
    return `https://drive.google.com/uc?export=view&id=${id}`;
  }

  // Lấy ID từ dạng /file/d/ID/view
  const dMatch = url.match(/\/d\/([^/]+)/);
  if (dMatch && dMatch[1]) {
    const id = dMatch[1];
    return `https://drive.google.com/uc?export=view&id=${id}`;
  }

  return url;
};

// Initial Data - Updated to v8 standards
const INITIAL_PROJECTS: Project[] = [
  { 
    id: 1, 
    title: "Xây dựng thương hiệu cá nhân Facebook", 
    description: "Xây dựng tuyến chủ đề bài viết chân thật, gần gũi. Định vị chuyên gia.", 
    image: "https://i.postimg.cc/BnZfD0Lp/1.jpg", 
    category: "Branding" 
  },
  { 
    id: 2, 
    title: "Workshop AI FOR TRAINER", 
    description: "Heona đảm nhận toàn bộ khâu tổ chức từ thiết kế nhận diện, setup không gian đến vận hành.", 
    image: "https://i.postimg.cc/QdNZ539n/5.jpg", 
    category: "Event" 
  },
  { 
    id: 3, 
    title: "Xây dựng thương hiệu trên TIKTOK – “Tịnh Khiêm Tarot”", 
    description: "Tăng nhận diện chuyên gia Tarot, video viral cao nhất đạt triệu view.", 
    image: "https://i.postimg.cc/QdNZ539q/2.jpg", 
    category: "Tiktok" 
  },
  { 
    id: 4, 
    title: "Lễ Ra Mắt Dự Án UNIHONE", 
    description: "Sự kiện đánh dấu bước ngoặt hệ sinh thái UniHome. Phụ trách trọn gói ý tưởng, concept, media.", 
    image: "https://i.postimg.cc/13R16Qnj/7.jpg", 
    category: "Event" 
  },
  { 
    id: 5, 
    title: "Xây dựng thương hiệu TRAINER THANH NGUYEN", 
    description: "Hệ thống giao diện hình ảnh được làm mới hoàn toàn, chuyên nghiệp và uy tín.", 
    image: "https://i.postimg.cc/bwYfbhD9/3.jpg", 
    category: "Branding" 
  },
  { 
    id: 7, 
    title: "Đêm nhạc yêu thương 4", 
    description: "Chương trình thiện nguyện lan tỏa Ánh Sáng & Tình Yêu Thương.", 
    image: "https://i.postimg.cc/HkW15gc3/4.jpg", 
    category: "Event" 
  },
  { 
    id: 8, 
    title: "Livestream Talkshow Series", 
    description: "Setup studio, ánh sáng và vận hành livestream đa điểm cầu chuyên nghiệp.", 
    image: "https://i.postimg.cc/2SjNvDbM/6.jpg", 
    category: "Livestream" 
  },
];

const INITIAL_SERVICES: Service[] = [
  {
    id: 'A',
    tag: 'Gói A',
    title: 'Xây dựng thương hiệu cá nhân',
    features: [
      'Tư vấn định vị thương hiệu cá nhân.',
      'Xây dựng nội dung truyền thông (hình ảnh, video, bài viết).',
      'Huấn luyện kỹ năng nói, phong thái chuyên nghiệp.',
      'Triển khai kênh truyền thông cá nhân (TikTok, Facebook, YouTube).'
    ],
    image: "https://i.postimg.cc/hvSh7Y9d/a1.jpg"
  },
  {
    id: 'B',
    tag: 'Gói B',
    title: 'Tổ chức sự kiện & khóa học',
    subTitle: '(workshop, seminar, đào tạo, retreat...)',
    features: [
      'Tổ chức sự kiện offline, workshop đào tạo.',
      'Hỗ trợ truyền thông sự kiện, quảng bá diễn giả.',
      'Dịch vụ tổ chức sự kiện trọn gói cho cá nhân & doanh nghiệp giáo dục / tâm linh.'
    ],
    image: "https://i.postimg.cc/zvJ3RQnW/a2.jpg"
  },
  {
    id: 'C',
    tag: 'Gói C',
    title: 'Hỗ trợ truyền thông & marketing',
    features: [
      'Dịch vụ viết bài PR, content marketing.',
      'Sản xuất nội dung video, bài viết viral.',
      'Quảng cáo Facebook, TikTok chuyên nghiệp.'
    ],
    image: "https://i.postimg.cc/6q9TGPdG/a3.jpg"
  },
  {
    id: 'D',
    tag: 'Gói D',
    title: 'Giải pháp hình ảnh thương hiệu',
    features: [
      'Thiết kế thương hiệu: Logo, bộ nhận diện thương hiệu, ấn phẩm truyền thông.',
      'Chụp ảnh Profile & Beauty cho doanh nhân, chuyên gia, diễn giả.'
    ],
    image: "https://i.postimg.cc/PJtN87m1/a4.webp"
  }
];

const INITIAL_CONTACT: ContactInfo = {
  phone: '0931 899 427',
  email: 'heonamedia@gmail.com',
  address: '45/30 đường số 1, Phường Thống Tây Hội, TP. HCM',
  facebook: '#',
  youtube: '#',
  instagram: '#',
  linkedin: '#'
};

const DEFAULT_STATE: ContentState = {
  projects: INITIAL_PROJECTS,
  services: INITIAL_SERVICES,
  contactInfo: INITIAL_CONTACT
};

interface ContentContextType extends ContentState {
  updateContact: (info: ContactInfo) => void;
  updateServices: (services: Service[]) => void;
  updateProjects: (projects: Project[]) => void;
  resetToDefaults: () => void;
}

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<ContentState>(DEFAULT_STATE);
  const [isLoaded, setIsLoaded] = useState(false);

  // 👉 KEY QUAN TRỌNG: Thay đổi version key để xóa cache cũ, ép tải lại dữ liệu mới
  const STORAGE_KEY = 'heona_content_data_v8';

  useEffect(() => {
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      try {
        const parsedData = JSON.parse(savedData);

        // Chuẩn hóa lại image trong projects kể cả khi lấy từ localStorage
        if (parsedData && parsedData.projects && parsedData.services) {
          parsedData.projects = parsedData.projects.map((p: Project) => ({
            ...p,
            image: normalizeDriveUrl(p.image),
          }));
          setState(parsedData);
        } else {
          console.warn("Saved data structure is invalid, using default.");
        }
      } catch (e) {
        console.error("Failed to parse saved content from localStorage", e);
      }
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }
  }, [state, isLoaded]);

  const updateContact = (info: ContactInfo) => setState(prev => ({ ...prev, contactInfo: info }));
  const updateServices = (services: Service[]) => setState(prev => ({ ...prev, services }));
  const updateProjects = (projects: Project[]) =>
    setState(prev => ({
      ...prev,
      projects: projects.map(p => ({ ...p, image: normalizeDriveUrl(p.image) })), // luôn normalize khi update
    }));
  
  const resetToDefaults = () => {
    if (window.confirm("Bạn có chắc chắn muốn khôi phục dữ liệu gốc? Mọi thay đổi sẽ bị mất.")) {
      setState(DEFAULT_STATE);
      localStorage.removeItem(STORAGE_KEY);
      window.location.reload();
    }
  };

  return (
    <ContentContext.Provider value={{ ...state, updateContact, updateServices, updateProjects, resetToDefaults }}>
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const context = useContext(ContentContext);
  if (!context) {
    throw new Error("useContent must be used within a ContentProvider");
  }
  return context;
};
